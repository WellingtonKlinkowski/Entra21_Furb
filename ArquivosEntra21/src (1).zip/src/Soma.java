
public class Soma {

	public static void main(String[] args) {

		int matriz1[][] = new int[4][4];
		int matriz2[][] = new int[4][4];

		matriz1[0][0] = 1;	matriz1[0][1] = 2;	matriz1[0][2] = 3;	matriz1[0][3] = 4;
		matriz1[1][0] = 5;	matriz1[1][1] = 6;	matriz1[1][2] = 7;	matriz1[1][3] = 8;
		matriz1[2][0] = 9;	matriz1[2][1] = 10;	matriz1[2][2] = 11;	matriz1[2][3] = 12;
		matriz1[3][0] = 13;	matriz1[3][1] = 14;	matriz1[3][2] = 15;	matriz1[3][3] = 16;

		matriz2[0][0] = 1;	matriz2[0][1] = 2;	matriz2[0][2] = 3;	matriz2[0][3] = 4;
		matriz2[1][0] = 5;	matriz2[1][1] = 6;	matriz2[1][2] = 7;	matriz2[1][3] = 8;
		matriz2[2][0] = 9;	matriz2[2][1] = 10;	matriz2[2][2] = 11;	matriz2[2][3] = 12;
		matriz2[3][0] = 13;	matriz2[3][1] = 14;	matriz2[3][2] = 15;	matriz2[3][3] = 16;

		System.out.println(matriz1[0][0] + matriz2[0][0] + " " + (matriz1[0][1] + matriz2[0][1]) + " "
				+ (matriz1[0][2] + matriz2[0][2]) + " " + (matriz1[0][3] + matriz2[0][3]));
		System.out.println(matriz1[1][0] + matriz2[1][0] + " " + (matriz1[1][1] + matriz2[1][1]) + " "
				+ (matriz1[1][2] + matriz2[1][2]) + " " + (matriz1[1][3] + matriz2[1][3]));
		
		System.out.println(matriz1[2][0] + matriz2[1][0] + " " + (matriz1[2][1] + matriz2[0][1]) + " "
				+ (matriz1[2][2] + matriz2[2][2]) + " " + (matriz1[2][3] + matriz2[2][3]));
		System.out.println(matriz1[3][0] + matriz2[0][0] + " " + (matriz1[3][1] + matriz2[3][1]) + " "
				+ (matriz1[3][2] + matriz2[3][2]) + " " + (matriz1[3][3] + matriz2[3][3]));

	}

}
