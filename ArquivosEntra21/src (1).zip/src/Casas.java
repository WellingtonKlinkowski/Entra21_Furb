
public class Casas {

	public static void main(String[] args) {

		int matriz[][] = new int[5][3];

		matriz[0][0] = 2104;
		matriz[1][0] = 1600;
		matriz[2][0] = 2400;
		matriz[3][0] = 1416;
		matriz[4][0] = 3000;

		matriz[0][1] = 3;
		matriz[1][1] = 3;
		matriz[2][1] = 3;
		matriz[3][1] = 2;
		matriz[4][1] = 5;

		matriz[0][2] = 399900;
		matriz[1][2] = 329900;
		matriz[2][2] = 369000;
		matriz[3][2] = 232000;
		matriz[4][2] = 539900;

		int somaArray = 0;
		double media = 0;

		int menosQuartos = Integer.MAX_VALUE;
		int maiorValor = Integer.MIN_VALUE;
		int menorCasa = Integer.MAX_VALUE;
		int maisQuartos = Integer.MIN_VALUE;

		for (int i = 0; i < matriz.length; i++) {

			somaArray = somaArray + matriz[i][2];
		}
		media = somaArray / matriz.length;
		System.out.println("A m�dia de pre�os � R$" + media);

		int locMenorCasa = 0;
		int locMaisCara = 0;
		int locMaisQuartos = 0;
		int locMenosQuartos = 0;

		for (int i = 0; i < matriz.length; i++) {

			if (matriz[i][0] < menorCasa) {

				menorCasa = matriz[i][0];
				locMenorCasa = i;
			}

			if (matriz[i][2] > maiorValor) {

				maiorValor = matriz[i][2];
				locMaisCara = i;
			}
			if (matriz[i][1] > maisQuartos) {

				maisQuartos = matriz[i][1];
				locMaisQuartos = i;
			}

			if (matriz[i][1] < menosQuartos) {

				menosQuartos = matriz[i][1];
				locMenosQuartos = i;
			}

		}

		int diferenca = matriz[locMaisQuartos][0] - matriz[locMenosQuartos][0];

		System.out.println("A menor casa custa R$" + matriz[locMenorCasa][2]);
		System.out.println("A casa mais cara tem " + matriz[locMaisCara][1] + " quartos");
		System.out.println(
				"A diferen�a de tamanho da casa com mais quartos para a com menos � " + diferenca + " metros.");
	}

}
