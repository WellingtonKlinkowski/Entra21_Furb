
public class LucroMeses {

	public static void main(String[] args) {

		int matriz[][] = new int[12][2];

		for (int i = 0; i < matriz.length; i++) {
			matriz[i][0] = i + 1;
			for (int j = 1; j < matriz[i].length; j++) {
				matriz[i][j] = i * i;
			}
		}

		for (int i = 0; i < matriz.length; i++) {

			System.out.println("No m�s " + matriz[i][0] + " a loja teve " + matriz[i][1] + " de lucro");

		}

	}

}
