
public class Conta {

	private String nome; // Vari�veis private para evitar que elas sejam acessadas diretamente
	private double saldo;

	public Conta(String nome, double saldo) {
		setNome(nome); // Colocando os sets no construtor
		setSaldo(saldo);
	}

	public void sacar(double valor) {
		setSaldo(getSaldo() - valor);
	}

	public void depositar(double valor) {
		setSaldo(getSaldo() + valor);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) { // Validando o nome
		if (nome.isBlank() || nome == null) {
			this.nome = "Erro";

		} else {
			this.nome = nome;

		}
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {

		this.saldo = saldo;
	}

}