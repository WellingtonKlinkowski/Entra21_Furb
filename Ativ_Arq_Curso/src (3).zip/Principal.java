
public class Principal {

	public static void main(String[] args) {

		Conta c1 = new Conta("Henrique", 5000); // Cria��o do objeto

		System.out.println("Saldo original: " + c1.getSaldo());

		c1.depositar(500); // Depositando 500 reais na conta c1

		System.out.println("Saldo depois do dep�sito: " + c1.getSaldo());

		c1.sacar(5000);

		System.out.println("Saldo depois do saque: " + c1.getSaldo());

		Conta c2 = new Conta("      ", 1000); // Cria��o do objeto sem nome

		System.out.println(c2.getNome()); // c2.getNome dever� retornar "Erro"

	}

}
