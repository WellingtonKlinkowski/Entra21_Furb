import java.text.DecimalFormat;
import java.util.Scanner;

public class Altura {

	public static void main(String[] args) {

		DecimalFormat df = new DecimalFormat("0.00");

		Scanner input = new Scanner(System.in);

		double altura = 0;

		for (int i = 0; i < 20; i++) {
			System.out.println("Entre a altura");
			altura += input.nextDouble();
		}

		System.out.println(df.format(altura / 20));

	}

}
