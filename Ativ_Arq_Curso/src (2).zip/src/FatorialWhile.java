import java.util.Scanner;

public class FatorialWhile {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Informe um n�mero");
		int numero = input.nextInt();

		int resultado = numero;

		while (numero > 1) {
			resultado = resultado * (numero - 1);
			numero--;
		}
		System.out.println(resultado);
	}

}
