import java.util.Scanner;

public class WhileTrue {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		int contador = 0;

		double altura = 0;

		while (true) {
			System.out.println("Entre com um n�mero");

			double numero = input.nextDouble();

			if (numero == 0) {
				break;

			}

			altura = altura + numero;

			contador++;

		}

		System.out.println("A m�dia �: " + altura / contador);

	}

}
