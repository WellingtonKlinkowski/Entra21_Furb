import java.util.Scanner;

public class Mod {
	public static void main(String[] args) {

		int somaPar = 0;

		int somaImpar = 0;

		for (int i = 1; i < 1001; i++) {

			if (i % 2 == 0) {
				somaPar = somaPar + i;
			} else {
				somaImpar = somaImpar + i;
			}

		}
		
		System.out.println("Soma par: " + somaPar);
		System.out.println("Soma impar: " + somaImpar);


	}
}