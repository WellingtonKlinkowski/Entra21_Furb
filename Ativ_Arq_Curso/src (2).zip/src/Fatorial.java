import java.util.Scanner;

public class Fatorial {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		int fact = 1;

		System.out.print("Digite um n�mero: ");
		int numero = input.nextInt();

		for (int i = 1; i <= numero; i++) {
			fact = fact * i;
		}

		System.out.println("Fatorial: " + fact);
	}
}