import java.util.Scanner;

public class MaiorValor {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		int maiorValor = Integer.MIN_VALUE;
		int menorValor = Integer.MAX_VALUE;

		while (true) {

			System.out.println("Entre com um n�mero");
			int numero = input.nextInt();

			if (numero == 0) {
				break;
			}
			if (numero > maiorValor) {
				maiorValor = numero;
			}
			if (numero < menorValor) {
				menorValor = numero;
			}

		}

		System.out.println("Maior valor: " + maiorValor);
		System.out.println("Menor valor: " + menorValor);

	}

}
