import java.util.Scanner;

public class While {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Entre com o primeiro n�mero");
		int numero1 = input.nextInt();
		System.out.println("Entre com o segundo n�mero");
		int numero2 = input.nextInt();
		System.out.println("Entre com o terceiro n�mero");
		int numero3 = input.nextInt();
		System.out.println("Entre com o quarto n�mero");
		int numero4 = input.nextInt();
		System.out.println("Entre com o quinto n�mero");
		int numero5 = input.nextInt();

		/*
		 * for (int i = 0; i < 1001; i++) { if (i == numero1 || i == numero2 || i ==
		 * numero3 || i == numero4 || i == numero5) { System.out.println(i); } }
		 */

		int contador = 0;

		while (contador < 1001) {
			if (contador == numero1 || contador == numero2 || contador == numero3 || contador == numero4
					|| contador == numero5) {
				System.out.println(contador);
			}
			contador++;
		}

	}

}
