import java.util.Scanner;

public class NAlunos {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		System.out.println("Entre com a quantidade de alunos na sala");
		int alunos = input.nextInt();

		int vinteAnos = 0;

		String nome = "";

		int contador = 0;

		// for (int i = 0; i < alunos; i++) {

		while (contador < alunos) {

			System.out.println("Qual o nome do aluno?");
			String nomeAtual = input.next();
			System.out.println("Quantos anos ele tem?");
			int idadeAtual = input.nextInt();

			if (idadeAtual == 18) {
				nome = nome + nomeAtual + " ";
			}

			if (idadeAtual > 20) {

				vinteAnos++;

			}

			contador++;

		}

		// }

		System.out.println("Nomes de alunos com 18 anos: " + nome);
		System.out.println("Alunos com mais de 20 anos: " + vinteAnos);

	}

}
