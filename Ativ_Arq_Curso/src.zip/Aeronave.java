
public class Aeronave {

	String modelo;
	int peso;
	int passageiros;
	int capacidadeCombustivel;
	int queimaDeCombustivel;

	// Apertar alt+shift+s ou clicar o bot�o direito e ir em source
	// Depois disso clique em:
	// Generate constructors using fields
	// Delete a linha "super();"

	public Aeronave(String modelo, int peso, int passageiros, int capacidadeCombustivel, int queimaDeCombustivel) {
		this.modelo = modelo;
		this.peso = peso;
		this.passageiros = passageiros;
		this.capacidadeCombustivel = capacidadeCombustivel;
		this.queimaDeCombustivel = queimaDeCombustivel;
	}

	public double tempoNoAr() {
		return capacidadeCombustivel / queimaDeCombustivel;
	}

}
