
public class Principal {

	public static void main(String[] args) {
		// Em vez de setar os atributos linha por linha,
		// Coloque todos no par�metro do m�todo Construtor

		Aeronave boeing = new Aeronave("Boeing 747", 183500, 300, 20000, 12);

		double tempoNoAr = boeing.tempoNoAr();

		System.out.println("Um Boeing 747 pode ficar no ar por " + tempoNoAr + " minutos");

	}

}
